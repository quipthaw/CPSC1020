/*
Manning Graham   
mcgraha        
PA2

File description: 
This is the header file for date.cpp, and it holds all function prototypes for said file.                    
*/

#ifndef DATE_H
#define DATE_H


#include <fstream>
#include <iostream>
#include <string>
using namespace std;



class Date {
    private: 
        int month;
        int day;
        int year;
        
    
    public:
        
        Date();
        Date(int m, int d, int y);
        void setMonth(int);
        void setDay(int);
        void setYear(int);
        void setDate(int m, int d, int y);
        string getStrMonth(int m);
        int getMonth()const;
        int getDay()const;
        int getYear()const;
        void printDate(fstream&);
        bool isDateValid(int m, int d, int y);
        bool isLeapYear(int y);
        static const string ARRAY[13];
        
};

#endif
