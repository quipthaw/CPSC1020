/*
Manning Graham   
mcgraha        
PA2

File description: 
This is the header file for time.cpp, and it holds all function prototypes for said file.                    
*/

#ifndef TIME_H
#define TIME_H

#include <fstream>
#include <iostream>

using namespace std;

class Time {
    private: 
        int hour;
        int minute;

    public:
        Time(); 
        Time(int , int); 
        void setHour(int); 
        void setMinute(int); 
        void setTime(int h, int m); 
        int getHour()const;
        int getMinute()const;
        void printTime()const; 
        void printTime(fstream&)const;
        bool isTimeValid(int hours, int minutes);

};

#endif
