
/*
Manning Graham   
mcgraha        
PA2

File description: 
This is the time driver file which holds the time class and functions to check if the input time is valid or not. 
It also holds functions which can send objects from the time class to the Calendar event class to be printed.                      
*/
#include "Time.h"

    //Determines if time is valid
    bool isTimeValid(int hours, int minutes)
    {
        int i = 0;
        if(0 <= hours && hours < 24){
          i++;
        }
        if(0 <= minutes && minutes < 60){
          i++;
        }
        if (i == 2){
          return true;
        }
        else{
            return false;
        }
    }
    //default constructor
    Time::Time()
    {
        hour = 0;
        minute = 0;
    }
    //parameterized constructor
    Time::Time(int h, int m)
    {
        hour = h;
        minute = m;
    }
    // setter that sets hour and minute
    void Time::setTime(int h, int m)
    {
        hour = h;
        minute = m;
    }
    //setter for hour
    void Time::setHour(int h)
    {
        hour = h;
    } 
    //setter for minute
    void Time::setMinute(int m)
    {
        minute = m;
    }
    //getter for hour
    int Time::getHour()const
    {
        return hour;
    }
    //getter for minute
    int Time::getMinute()const
    {
        return minute;
    }
    //prints the time to the output file
    void Time::printTime(fstream& out)const
    {
        string pod;
        string h;
        string m = to_string(minute);
        
        if(hour >= 12){
            if(hour > 12){
                h = to_string(hour - 12);
                pod = "PM";
            }
            if(hour == 12){
                h = to_string(hour);
                pod = "Noon";
            }
        }
        else {
            h = to_string(hour);
            pod = "AM";
        }      

        if(minute < 10)
        {
            out << h << ":0" << m << " " << pod << endl;
        }
        else 
        {
            out << h << ":" << m << " " << pod << endl;
        }
    }