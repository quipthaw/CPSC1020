/*
Manning Graham   
mcgraha        
PA2

File description: 
This is the calendar event driver file which holds the calendar event class 
and can call other classes to print the full calendar events into the output files.                     
*/

#include "CalendarEvent.h"
#include "Time.h"
#include "Date.h"

//default constructor
CalendarEvent::CalendarEvent(){
        int month = 0;
        int day = 1;
        int year = 1900;
        int hour = 1;
        int minute = 0;
        string name = "My Birthday";
        
        eventName = name;
        calTime.setTime(hour, minute);
        calDate.setDate(month, day, year);
}
//parameterized constructor
CalendarEvent::CalendarEvent(int month, int day, int year, int hour, int minute, string name){
            
            eventName = name;
            calTime.setTime(hour, minute);
            calDate.setDate(month, day, year);

        }
//setter for the event
void CalendarEvent::setEvent(string name, string date, string time){
    eventName = name;
    eventTime = time;
    eventDate = date;
}
//getter for the event
string CalendarEvent::getEvent()const
{
    return eventName, eventTime, eventDate;
}
//determines if the date is valid or not
bool CalendarEvent::isEventDateValid(int m, int d, int y){
    
    isDateValid( m, d, y);
    
}
//determines if the time is valid or not
bool CalendarEvent::isEventTimeValid(int hours, int minutes){
    isTimeValid( hours , minutes);
}
// prints the date to output file using print functions from other classes
void CalendarEvent::printCalendar(fstream& out){
    out << "---------------------------------" << endl;
    out << eventName << '\n';
    calTime.printTime(out);
    calDate.printDate(out);
    out << "---------------------------------" << endl;
}

