/*
Manning Graham   
mcgraha        
PA2

File description: 
This is the header file containing the function prototypes for the calendar event driver file.
*/


#ifndef CALENDAREVENT_H
#define CALENDAREVENT_H
#include <iostream>
#include <string>
#include <fstream>

#include "Time.cpp"
#include "Date.cpp"

class CalendarEvent {
    
    public:
        CalendarEvent();
        CalendarEvent(int month, int day, int year, int hour, int minute, string name);
        void setEvent(string name, string time, string date);
        void printCalendar(fstream& out);
        bool isEventDateValid(int m, int d, int y);
        bool isEventTimeValid(int hours, int minutes);
        string getEvent()const;

    private:
        string eventTime;
        string eventDate;
        string eventName;
        Time calTime;
        Date calDate;
};


#endif
