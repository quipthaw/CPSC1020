/*
Manning Graham   
mcgraha        
PA2

File description: 
This is the header file for functions.cpp, and it holds all function prototypes for said file.                    
*/


#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include "CalenderEvent.cpp"

void readData(fstream& f, vector<CalendarEvent>& good, vector<CalendarEvent>& bad, char *argv[]);
void checkArguments(int argc);
void isOpen(fstream&, char*);


#endif