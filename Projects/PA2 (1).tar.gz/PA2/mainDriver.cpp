/*
Manning Graham   
mcgraha        
PA2

File description: 
This is the main driver file which checks if command line arguments are valid,
and if the input file entered is open. It then reads the data into vectors before 
sorting and printing them accordingly.                    
*/

#include <vector>
#include <iostream>
#include <iterator>
#include "Functions.cpp"

int main(int argc, char *argv[]){

    vector<CalendarEvent> good;
    vector<CalendarEvent> bad;
    
    fstream infile;
    infile.open(argv[1], istream::in);
    checkArguments(argc);
    isOpen(infile, argv[1]); 
    readData(infile, good, bad, argv); 

    infile.close();
    
    return 0;
}