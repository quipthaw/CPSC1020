/*
Manning Graham   
mcgraha        
PA2

File description: 
This is the function driver file which takes all functions from all driver files (excluding main driver), 
and uses them to perform the main function of reading and sorting information from the input file and 
separate them into two good and bad output files. It also holds funtions to check the command inputs, and check if the input file is open.                    
*/

#include "Functions.h"
#include <vector>

using namespace std;

//Reads, sorts, and prints data
void readData(fstream& f, vector<CalendarEvent>& good, vector<CalendarEvent>& bad, char *argv[])
{
    fstream outfileBad;
    fstream outfileGood;
    outfileBad.open(argv[3], istream::out);
    outfileGood.open(argv[2], istream::out);
    isOpen(outfileGood, argv[2]);
    isOpen(outfileBad, argv[3]);

    string name, day, month, year, minute, hour; 
    string temp, temp2, temp3;
    string slash = "/";
    string space = " ";

    int dGood[100];
    int mGood[100];
    int dBad[100];
    int mBad[100];
    
    int strlength;
    int Name, Day, Month, Year, Minute, Hour;

        for(int i = 0; i <5;i++) 
        {                      
                getline(f, temp); 

                strlength = temp.length();    
                int pointOfSlash;
                for( int m = 0; m < strlength; m++){ // for loop finding point in string where first slash occurs
                        char let = temp.at(m);
                        if(let == '/'){
                                pointOfSlash = m;
                                temp2 = temp.substr(m+2, 1);
                                temp3 = temp.substr(m-2, 1);
                                m = strlength;
                        }
                }

                if(temp2.compare(slash) != 0)
                {                  // checks if char behind day number is not a slash
                        day = temp.substr((pointOfSlash + 1 ), 2); //if not the day is two digits
                        Day = stoi(day);              
                }
                else
                {
                        day = temp.substr((pointOfSlash + 1 ), 1); //if so the day is one digit
                        Day = stoi(day); 
                        
                }
        
                if(temp3.compare(space) != 0)   // checks if point behind month number is not a space
                {                                               
                        month = temp.substr((pointOfSlash - 2), 2); // if not the month is two digits long
                        Month = stoi(month); 
                }
                else
                {
                        month = temp.substr((pointOfSlash - 1), 1); // if so the month is one digit
                        Month = stoi(month);
                }

                year = temp.substr((pointOfSlash + 3), 4); //sets new year string from temp string substring.
                Year = stoi(year); //turns string into int
                
                minute = temp.substr((strlength - 3), 2); 
                Minute = stoi(minute); 

                hour = temp.substr((strlength - 6), 2); 
                Hour = stoi(hour);       
        


                for(int j = 0; j < strlength; j++) //for loop finds first digit in temp string determining where the name of event ends
	        {
	                if(isdigit(temp.at(j))) 
	                {
                                name = temp.substr(0, j); 
                                break;
		        }
	        }
                CalendarEvent Event( Month, Day, Year,Hour, Minute, name); 
                if( Event.isEventDateValid(Month, Day, Year)) 
                {
                        if(Event.isEventTimeValid(Hour, Minute))
                        {       
                                mGood[i] = Month; // array tools used to sort the vector by date later. 
                                dGood[i] = Day;
                                good.emplace_back(Event);

                        }
                        else
                        {       
                                mBad[i] = Month; 
                                dBad[i] = Day;
                                bad.emplace_back(Event);
                        }
                }
                else 
                {       
                        mBad[i] = Month; 
                        dBad[i] =Day;
                        bad.emplace_back(Event);
                }
        }

        if(good.size() > 0){ // only allows bubble sort to function if there are strings within good vector
                int swapped = 1;
                for (int i = 0; swapped != 0 ; i++) 
                { 
                        swapped = 0; 
                        for (int j = 0; j < good.size()-1; j++) 
                        { 
                                if(mGood[j] > mGood[j+1]){
                                        swap(good[j+1], good[j]);
                                        swap(mGood[j+1], mGood[j]);
                                        swap(dGood[j+1], dGood[j]);
                                        swapped = 1;
                                }
                                if(mGood[j] == mGood[j+1]){
                                        if(dGood[j] > dGood[j+1]){
                                                swap(good[j+1], good[j]);
                                                swap(dGood[j+1], dGood[j]);
                                                swap(mGood[j+1], mGood[j]);
                                                swapped = 1;
                                        }
                                }
                        } 
                }
        }
        if(bad.size() > 0){ // only allows bubble sort to function if there are strings within bad vector.
                int swapped = 1;
                for (int i = 0; swapped != 0; i++) 
                {        
                        swapped = 0; 
                        for (int j = 0; j < bad.size()-1; j++) 
                        { 
                                if(mBad[j] > mBad[j+1]){
                                        swap(bad[j+1], bad[j]);
                                        swap(mBad[j+1], mBad[j]);
                                        swap(dBad[j+1], dBad[j]);
                                        swapped = 1;        
                                }
                                
                                if(mBad[j] == mBad[j+1]){
                                        if(dBad[j] > dBad[j+1]){
                                                swap(bad[j+1], bad[j]);
                                                swap(mBad[j+1], mBad[j]);
                                                swap(dBad[j+1], dBad[j]);
                                                swapped = 1;
                                        }
                                } 
                        }  
                }
        }  
        
        unsigned int size = good.size(); 
        for( unsigned int i = 0; i < size; i++){
                good[i].printCalendar(outfileGood);            //prints good vector into good output file  
        }

        unsigned int size2 = bad.size();
        for( unsigned int i = 0; i < size2; i++){
                bad[i].printCalendar(outfileBad);      // prints bad vector into bad output file
        }

        outfileGood.close(); 
        outfileBad.close();
}
//Checks to see if all files opened correctly
void isOpen(fstream& f, char* filename)
{
        if(f.is_open()){}
        else
        {
                cout << '\n' << "Error in opening file "<< filename << '\n';
                exit(0);
        } 
} 
//Checks to see if there are the correct amount of command inputs
void checkArguments(int argc)
{       
        if(argc != 4){
        cout << "There are not enough arguments!" << endl;
        exit(-1);
        } 
}
