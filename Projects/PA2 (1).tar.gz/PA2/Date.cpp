/*
Manning Graham   
mcgraha        
PA2

File description: 
This is the time driver file which holds the date class and functions to check if the input date is valid or not. 
It also holds functions which can send objects from the date class to the Calendar event class to be printed.                      
*/

#include "Date.h"
    // default constructor
    Date::Date()
    {
        int month = 1;
        int day = 1;
        int year = 1900;
    }
    //parameterized constructor
    Date::Date(int m, int d, int y)
    {
            month = m;
            day = d;
            year = y;
    }
    //setter for the month
    void Date::setMonth(int m)
    {
        month = m;
    }
    //setter for the day
    void Date::setDay(int d)
    {
        day = d;
    }
    //setter for the year
    void Date::setYear(int y)
    {
        year = y;
    }
    //setter for date as a whole
    void Date::setDate(int m, int d, int y)
    {
        month = m;
        day = d;
        year = y;
    }
    //gets the corresponding month name for the month number
    string Date::getStrMonth(int m)
    {
        switch(m)
        {
        case 1: return "January";
        case 2: return "February";
        case 3: return "March";
        case 4: return "April";
        case 5: return "May";
        case 6: return "June";
        case 7: return "July";
        case 8: return "August";
        case 9: return "September";
        case 10: return "October";
        case 11: return "November";
        case 12: return "December";
        }
    }
    //getter for the month
    int Date::getMonth()const
    {
        return month;
    }
    //getter for the day
    int Date::getDay()const
    {
        return day;
    }
    //getter for the year
    int Date::getYear()const
    {
        return year;
    }
    // prints the date to the output file
    void Date::printDate(fstream& out)
    {
        string m = getStrMonth(month);
        string d = to_string(day);
        string y = to_string(year);

        out << m << ", " << d << " " << y << '\n';
        // put to output file
    }
    //determines if the given date is valid or not
    bool isDateValid(int m, int d, int y)
    {
        int i = 0;
        if(m >= 1 && m <= 12){
            i++;
        }
        if(d >= 1 && d <= 31){
            i++;
        }
        if(y >= 1900 && y <= 2019){
            i++;
        }
        if( i == 3){
            return true;
        }
        else{
            return false;
        }
    }
    //determines if the year is a leap year
    bool isLeapYear(int y)
    {
        if(y%4 == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    static const string ARRAY[13]{};
