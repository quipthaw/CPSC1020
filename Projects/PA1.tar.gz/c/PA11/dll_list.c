
#include "dll_list.h"


int printMenu(){ 
int choice = 0;
printf("\n\n1. initialize list of students\n2. add additional student in order of id number\n3. delete student\n4. search students by id number\n5. search students by last name\n6. show number of students in list\n7. print students\n8. quit program\n\n");
scanf("%d", &choice);
if(choice < 1 || choice > 8){
    printf("\ninvalid choice please try again\n");
    return 66;
    }
    else {
    return choice;
    }
}

list_t *newList(){ // creates a new list; returns a pointer to the new list
list_t *list;
list = (list_t*)malloc(sizeof(list_t));
(*list).head = NULL;
(*list).tail = NULL;
(*list).size = 0;
return list; 
}

void initializeList( list_t *list, FILE *inFile ){

    int size = 0;
    int whichInput = 1;

    fscanf(inFile, "%d", &size);
    addToList(list, whichInput, inFile);
}


// calls addToList() sending the input file pointer (which is the file
// specified at the command-line)
// note – the first value in the input file is the number of students in the
// file – that will be the first value read in from the file so you
// know how many times the loop needs to go


    

student_t *newStudent( FILE *inFile, int whichInput )
{
 student_t *k = malloc(sizeof(student_t));
     if(whichInput == 1){
        fscanf(inFile, "%d %f %d %s %d %d %s %s", &(k->age),&(k->gpa),&(k->cuid),(k->dob.month),&(k->dob.day),&(k->dob.year),(k->lastName),(k->firstName));
        k->next = k;   
     }
    if(whichInput != 1){
        printf("\nenter student age:");
        scanf("%d", &(k->age));
        printf("\nenter student GPA:");
        scanf("%f", &(k->gpa));
        printf("\nenter student CUID:");
        scanf("%d", &(k->cuid));
        printf("\nenter student Birth Month:");
        scanf("%s", (k->dob.month));
        printf("\nenter student Birth Day:");
        scanf("%d", &(k->dob.day));
        printf("\nenter student Birth Year:");
        scanf("%d", &(k->dob.year));
        printf("\nenter student Last Name:");
        scanf("%s", (k->lastName));
        printf("\nenter student First Name:");
        scanf("%s", (k->firstName));
        k->next = k;
        printf("\nNew student added!\n ");
    }
    return k;
}
    

// called by addToList() function
// creates and initializes a new student node from the input file pointer
// sent in (either the file pointer specified on the command-line
// or stdin that has been reset)
// whichInput is intended to be a flag will which determine if the
// user prompts are to be printed or not
// returns a pointer to the student that was just created

void addToList( list_t *list, int whichInput, FILE *inFile ){

student_t *k;
    if(whichInput == 1){
        for( int i = 0; i < 10; i++){
        k = newStudent(inFile, whichInput);
        if((*list).size == 0) {
            (*list).tail = k;
        }
        (*k).next = (*list).head;
        (*list).head = k;
        (*list).size += 1;
        }
        whichInput +=1;
    }
    else{
    k = newStudent(inFile, whichInput);
        (*k).next = (*list).head;
        (*list).head = k;
        (*list).size += 1;
    }
}


// creates a new student by calling newStudent() and then adds the returned
// student to the list in order of cuid number

void deleteStudent( list_t *list, int idNum ){
    student_t *k,*p;

    if(list->head!=NULL) {
        k=list->head;
        if(k->cuid==idNum) {
            list->head = list->head->next;
            list->size -= 1;
            free(k);
            return;
        }

        p = k;
        k = k->next;
        while(k!=NULL) {
            if(k->cuid==idNum) {
                p->next=k->next;
                list->size -= 1;
                if(k == list->tail) {
                    list->tail = p;
                }
                free(k);
                break;
            } else {
                p=k;
                k=k->next;
            }
        }
        printf("Student Removed");
    }
    
}
// deletes the student with the cuid sent in as idNum

void searchByID( list_t *list ){
student_t *temp;
    int i = 0;
    int j = 0;
    if(list->head==NULL){
        printf("\nList is empty, No matches");
    } 
    else {
        temp=list->head;
        temp=temp->next;
        printf("\nPlease enter The CUID of person to be searched: ");
        scanf("%d", &i);

        while(temp!=NULL) {
            j = temp->cuid;
            if(j == i){
            printf("\nMatch Found:\n\tid\tlast_name\tfirstname\tdate\tmonth\tyear\tgpa\n %d\t%s\t%s\t%d\t%s\t%d\t%.1f\n",temp->cuid,temp->lastName,temp->firstName,temp->dob.day,temp->dob.month,temp->dob.year,temp->gpa);
            break;
            }
            else {
                temp=temp->next;
                if(temp == NULL){
                    printf("\nNo Matches Found\n");
                }
            }
        }
    }
}
// searches list for student specified by the id number as specified by
// the user
// if found, student info is printed; if not found, an appropriate message
// is printed to the user

void searchByLN ( list_t *list ){
    student_t *temp;
    char ln[20];
     if(list->head==NULL){
        printf("\nList is empty, No matches");
    } 
    else {
        temp=list->head;
        temp=temp->next;
        printf("\nPlease enter last name of person to be searched: ");
        scanf("%s", ln);

        while(temp!=NULL) {
            if(strcmp(temp->lastName, ln)!=0){
                temp=temp->next;
            }
            else{
            printf("\nMatch Found:\n\tid\tlast_name\tfirstname\tdate\tmonth\tyear\tgpa\n %d\t%s\t%s\t%d\t%s\t%d\t%.1f\n",temp->cuid,temp->lastName,temp->firstName,temp->dob.day,temp->dob.month,temp->dob.year,temp->gpa);
            break;
            }
        }
    }
}
// searches list for student specified by the last name as specified by
// the user
// student info is printed for all students with that last name
// if not found, an appropriate message is printed to the user

int isEmpty( list_t *list ){
 return list->size == 0;
 }
// returns 1 if the list is empty and 0 if it is not empty

int size( list_t *list ){
    student_t *temp;
    int i = 0;
    if(list->head==NULL){
        return 0; 
    } 
    else {
        temp=list->head;
        temp=temp->next;
        while(temp!=NULL) {
            if(temp->cuid == 0){
                temp=temp->next;
            }
            else{
            i+=1;
            temp=temp->next;
            }
        }
        return i;
    }
}
// returns the size of the list

void printStudents ( list_t *list ){
student_t *temp;
    if(list->head==NULL){
        printf("\nStudent list is empty\n");
    } 
    else {
        temp=list->head;
        temp=temp->next;
        printf("id\tlast_name\tfirstname\tdate\tmonth\tyear\tgpa\n");
        while(temp!=NULL) {
            if(temp->cuid == 0){
                temp=temp->next;
            }
            else{
            printf("%d\t%s\t%s\t%d\t%s\t%d\t%.1f\n",temp->cuid,temp->lastName,temp->firstName,temp->dob.day,temp->dob.month,temp->dob.year,temp->gpa);
            temp=temp->next;
            }
        }
    }
}
// prints the students in the list