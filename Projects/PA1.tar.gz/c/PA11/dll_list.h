#ifndef DLL_LIST_H
#define DLL_LIST_H

#include "stdio.h"
#include "stdlib.h"
#include "limits.h"
#include "string.h"
#include "stdbool.h"

typedef struct {
	char month[4];
	int day;
    int year;
} dateOfBirth;

typedef struct student {
  int age;
  int cuid;
  float gpa;
  dateOfBirth dob;
  char lastName[20];
  char firstName[15];
  struct student *prev;
  struct student *next;
} student_t;

typedef struct list {
  student_t *head;
  student_t *tail;
  int size;
} list_t;


int printMenu();
list_t *newList();
void initializeList( list_t *list, FILE *inFile  );
student_t *newStudent( FILE *inFile, int whichInput );
void addToList( list_t *list, int whichInput, FILE *inFile );
void deleteStudent( list_t *list, int idNum );
void searchByID( list_t *list );
void searchByLN( list_t *list );
int isEmpty( list_t *list );
int size( list_t *list );
void printStudents ( list_t *list );


#endif /* DLL_LIST_H */
