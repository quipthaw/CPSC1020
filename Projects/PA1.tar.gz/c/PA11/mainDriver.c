#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "dll_list.h"
int main(int argc, char * argv[])
{
   int choice = 0;
   int id = 0;
   int whichinput = 0;
   FILE *inFile;
    inFile = fopen("students.txt", "r"); 
    if(inFile==NULL){
        printf("Error\n");
        return -1;
    }
    list_t *list = newList();
   do
   {
    choice = printMenu();
    switch(choice)
    {

           case 1://initialize list of students
                   initializeList(list, inFile);
                   printf("\nlist initialized. \n\n");
                   break;
           
           case 2://add additional student to the list:
                   addToList(list, whichinput, inFile);
                   break;
           
           case 3://delete student
                   printf("\nPLease enter CUID number: ");
                   scanf("%d",&id);
                   deleteStudent(list, id);
                   break;
           
           case 4://search students alphabetically
                   searchByID(list);
                   break;
           
           case 5://search students by id
                   searchByLN(list);
                   break;
           
           case 6:   //number of students in the list
                   printf("\nThere are %d students in list\n\n",size(list));
                   break;
           
           case 7:   //printing students in the list
                   printStudents(list);
                   break;
           
           case 8:
                   printf("\nQuiting program...\n");
                   return 0;
           case 66:
                   continue;

       }
   }while(choice!=9);

   fclose(inFile);
   return 0;
}