#ifndef DATE_H
#define DATE_H
#include <string>
#include <sstream>
#include <iomanip>

using namespace std;

class Date{

    private:
        int month, day, year;

    public:
        static bool compare(const Date& lhs, const Date& rhs);

    static const string MONTHS[12];

    Date();
    ~Date();

    int get_month() const;
    int get_day() const;
    int get_year() const;
    void set_month(int month);
    void set_day(int day);
    void set_year(int year);
    bool operator<(Date& lhs);

};

#endif