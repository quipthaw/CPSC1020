#include <iostream>
#include <fstream>
#include <iomanip>
#include <algorithm>
#include "Date.h"


using namespace std;

void print(ofstream &out, const Date &print);

int main(int argc, char *argv[])
{   

    ifstream infile;

    infile.open(argv[1]);
    
    if(infile.fail())
    {
        cout<<"Unable to open file 1 " <<endl;
        return -1;
    }

    ofstream outfile;

    outfile.open(argv[2]);

    if(outfile.fail())
    {
        cout<<"Unable to open file 2 "<<endl;
        return -1;
    }

    int n, month, year, day;

    infile >> n;

    Date *dates = new Date[n];

    for(int i=0; i<n; i++)
    {
        infile >> month >> day >> year;
        dates[i].set_month(month);
        dates[i].set_day(day);
        dates[i].set_year(year);
    }

    sort(dates, dates + n, Date::compare);
    
    for(int i=0; i<n; i++){
        print(outfile, dates[i]);

    }

    outfile.close();
    infile.close();

return 0;
}

