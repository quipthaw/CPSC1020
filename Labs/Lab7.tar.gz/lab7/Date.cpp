#include <iostream>
#include <fstream>
#include <iomanip>
#include <algorithm>
#include "Date.h"

const string Date::MONTHS[] = {"JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"};

Date::Date()
{
    this->month = 1;
    this->day = 1;
    this->year = 1000;
}

Date::~Date(){}

bool Date::compare(const Date& lhs, const Date& rhs){

    if(lhs.year<rhs.year){
        return true;
    }
    else if(lhs.year>rhs.year){
        return false;
    }
    else{

        if(lhs.month<rhs.month){
            return true;
        }
        else if(lhs.month > rhs.month){
            return false;
        }
        else{
            return lhs.day<rhs.day;
        }
    }
}

int Date::get_month() const{
    
    return this->month;
}

int Date::get_day() const{
    
    return this->day;
}

int Date::get_year() const{
    
    return this->year;
}

void Date::set_month(int month){
    
    this->month = month;
}

void Date::set_day(int day){
    
    this->day = day;
}

void Date::set_year(int year){

    this->year = year;
}

bool Date::operator<(Date& lhs){

    return compare(lhs, *this);
}

void print(ofstream &out, const Date &print)    
{
out << left << setw(10) << Date::MONTHS [print.get_month()-1] << setw(3) << print.get_day() << setw(5) << print.get_year() << endl;
}