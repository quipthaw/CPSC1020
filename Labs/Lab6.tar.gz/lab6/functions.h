
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <algorithm>
#include <fstream>
#include <string>

using namespace std;

struct Student{
    string firstName;
    string lastName;
};
void ascNameSort(Student data[]);
void decNameSort(Student data[]);
void printData(Student data[]);
void readData(int x);