#include <iostream>
#include <algorithm>
#include <fstream>
#include <string.h>
#include <string>
#include <vector>
#include "functions.cpp"

using namespace std;

int main(void){
    int x;
    while(x!=3){
        cout << "Enter 1 for ascending, 2 for decending, or 3 to exit program: ";
        cin >> x;
        
        readData(x);
        if(x == 3){
            cout << "Ending session" << endl;
        }
        if(x > 3){
            cout << "Invalid input" << endl;
        }
    }
return 0;
}