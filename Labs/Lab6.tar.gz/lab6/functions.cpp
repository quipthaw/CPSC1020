#include <iostream>
#include <algorithm>
#include <fstream>
#include <string.h>
#include <string>
#include <vector>
#include "functions.h"

using namespace std;

void readData(int x){
    
    ifstream infile("data.txt");
    struct Student data[10];
    int i = 0;
    if(!infile){
        cerr << "cant open file" << std::endl;
        exit (-1);
    }
    while(i < 10){
        if(infile.eof()){
        break;
        }
        getline(infile, data[i].lastName);
        i++;
    }
    infile.close();



    if(x == 1){ 
        ascNameSort(data);
    }
    if(x == 2){

        decNameSort(data);
    }
}

void ascNameSort(Student data[]){
    int j;
    int k;
    int l;
    int m;
    int i;

    int swapNum = 0;
    i = 0;

    while(swapNum < 300){
        for(i = 0; i < 8; i++){
            j = data[i].lastName.at(0);
            k = data[i + 1].lastName.at(0);
            l = data[i].lastName.at(1);
            m = data[i + 1].lastName.at(1);
            
            if(j > k){
                swap(data[i].lastName, data[i+1].lastName);
            }
            if(j == k){
                if(l > m){
                swap(data[i].lastName, data[i+1].lastName);
                }
            }
        }
        swapNum = swapNum + 1;
    }


    cout << '\n';
    printData(data);
    cout << '\n';

}


void decNameSort(Student data[]){
   
    int j, k, l, m; 
    int i = 0;
    int swapNum = 0;

    while(swapNum < 300){
        for(i = 0; i < 8; i++){
            j = data[i].lastName.at(0);
            k = data[i + 1].lastName.at(0);
            l = data[i].lastName.at(1);
            m = data[i + 1].lastName.at(1);
            
            if(j < k){
                swap(data[i].lastName, data[i+1].lastName);
            }
            if(j == k){
                if(l < m){
                swap(data[i].lastName, data[i+1].lastName);
                }
            }
        }
        swapNum = swapNum + 1;
    }
    cout << '\n';
    printData(data);
    cout << '\n';
}

void printData(Student data[]){
    ofstream outputFile;
    outputFile.open("out.txt");
    for(int i = 0; i < 9; i++){
        cout << data[i].lastName << endl;
        outputFile << data[i].lastName << endl;
    }
    cout << '\n' << "Above list printed to output file" << '\n';

}