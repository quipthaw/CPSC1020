/*
   Manning Graham   
   mcgraha        
   Lab 9
   Lab Section: 4                  
*/ 
#ifndef BOOK_H
#define BOOK_H
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;
class Book {
    
    public:
        int bookID;
        int year;
        double rating;
        string title;

    
    int getID() const;          // returns the book ID
    string getTitle() const;    // returns the title
    int getYear() const;        // returns the publication year
    double getRating() const;

    void updateBooks(int idNum[100], int id);
    void initializeBooks(ifstream &inFile);
    void printBooks();
};
#endif