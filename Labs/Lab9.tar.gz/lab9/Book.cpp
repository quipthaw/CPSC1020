/*
   Manning Graham   
   mcgraha        
   Lab 9
   Lab Section: 4                  
*/ 
#include "Book.h" 

void Book::initializeBooks(ifstream &inFile)
 {
    inFile >> bookID;
    inFile >> year;
    inFile >> rating;
    getline(inFile, title);
}

void Book::printBooks()
 {
    cout << "  "; 
cout << setw(2) << bookID << " " << year << " " << rating << " " << title << " " << '\n';
}

void Book::updateBooks(int idNum[100],int id)
{
    cout << '\n' << "Please Enter the updated year and rating for book ID " << id << '\n';
    cin >> year ; cin >> rating;
}