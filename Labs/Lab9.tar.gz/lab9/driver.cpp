/*
   Manning Graham   
   mcgraha        
   Lab 9
   Lab Section: 4                  
*/ 
#include "Book.h"
int main(int argc, char * argv[]) {
   
    Book allBooks[8]; // calls constructor 8 times
    int numbooks = 8;
    int idNum[100];
    int id;
    int temp = 0;
    int dontPrint = 100;
    ifstream inputFile("books.txt");
    
    for (int i = 0; i < numbooks; i++)
    {
        allBooks[i].initializeBooks(inputFile);
        idNum[allBooks[i].bookID] = i;
        temp += allBooks[i].rating;
    }
    
    
    cout << endl ;
    cout << '\n' << "number of books inserted: " << numbooks << endl;
	cout << "Information of books sorted by their ID:" << endl;
    for (int i = 0; i < 8; i++) 
    {
        allBooks[i].printBooks();
    }

    cout << '\n' << "Please Enter ID of a Book to update it's year and rating:" << '\n';
	cin >> id;
    allBooks[idNum[id]].updateBooks(&idNum[100], id);
    for (int i = 0; i < 8; i++)
    {   
        allBooks[i].printBooks();
    }

    cout << "\nAverage rating for Books is " << (temp / 8) << '\n';

    cout << "\nEnter the ID of the book you wish to remove" << endl;
    cin >> id;
    cout << "\nUpdated List:" << endl;
     for (int i = 0; i < 8; i++)
    {   
        if (allBooks[i].bookID == id)
        {
            i++;
        }
        allBooks[i].printBooks();
    }
    inputFile.close();

 return 0;
}