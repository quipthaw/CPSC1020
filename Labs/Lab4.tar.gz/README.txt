/***************
Manning Graham
Mcgraha
Lab 4 
Section 4
****************/

message is 1021

