#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <vector>


int main()
{
	int i,sum = 0,avg = 0,x = 0;
	std::vector<int> vector;
	vector.reserve(10000);
	std::ifstream infile ("numbers.txt", std::ifstream::in);
	if( !infile  ) {
        	std::cerr << "Can't open file " << std::endl;
        	std::exit( -1 );
        }
		
	while(true){
		if(infile.eof()){
			break;
		} 
        	infile >> x;
		vector.emplace_back(x);
	}
	int size = vector.size();
	for( i = 0; i < size; i++){
		sum += vector[i];
	}
	avg = sum / size;
	std::cout << "\nAverage is " << avg << '\n';
    
    vector.clear();
    

    return 0;
}
