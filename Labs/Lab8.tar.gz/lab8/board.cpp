 
/*
   Manning Graham   
   mcgraha        
   Lab 8
   Lab Section: 4                  
*/ 
#include <vector>
#include <string>
#include "board.hpp"
#include <sstream>
#include <iostream>
       
       // our gameboard
        std::vector<std::string> pieces;
        std::string gameboard[3][3];
        int numTurns;
        //This initializes the board
        Board::Board(){
            gameboard[0][0]='1';
            gameboard[0][1]='2';
            gameboard[0][2]='3';
            gameboard[1][0]='4';
            gameboard[1][1]='5';
            gameboard[1][2]='6';
            gameboard[2][0]='7';
            gameboard[2][1]='8';
            gameboard[2][2]='9';
            
            pieces.emplace_back("x");
            pieces.emplace_back("o");
        }
        
        // Clears the vector 
        Board::~Board(){
            gameboard[3][3].clear();
        }        
        
        // This function will print the gameboard. 
        std::string Board::print(){
             std::stringstream board;
            for(int i=0; i<3; i++){
                board;
                std::cout << gameboard[i][1] << "|" <<  "|" << gameboard[i][2]<< "|" << std::endl;
            }
            return board.str();
        }
        
        // This function will take in the position the game piece will be placed in and the gamepiece.         
        void Board::insert_piece(int pos, std::string p){
            
            if(((numTurns+1)/2)%2 == 0){
                gameboard[(pos-1)/3][(pos-1)%3]=get_piece(0);
            }
            if (((numTurns-1)/2)%2 == 1){
               
               gameboard[(pos-1)/3][(pos-1)%3]=get_piece(1);
            }
        }
        
        // This will return the piece you need for insert_piece. It will get this value
        // From the Vector above.
        std::string Board::get_piece(int pos){
            return pieces.at(pos);
        }        
        
        // passes a gamepiece token into this function to check if it won.
        bool Board::won(std::string p){
            int i;
            for (i = 0; i < 3; i++) {
                if ((gameboard[0][i] == gameboard[1][i]) && (gameboard[1][i] == gameboard[2][i])) {
                return true;
            //Vertical win
            }
        }
        for (i = 0; i < 3; i++) {
            if ((gameboard[i][0] == gameboard[i][1]) && (gameboard[i][1] == gameboard[i][2])) {
                return true;
            //Horizontal win
            }
        }
        if((gameboard[0][0] == gameboard[1][1]) && (gameboard[1][1] == gameboard[2][2])){
            return true;
        //Diagonal top-left to bottom-right win
        }
        if((gameboard[0][2] == gameboard[1][1]) && (gameboard[1][1] == gameboard[2][0])){
            return true;
        //Diagonal top-right to bottom-left win//
        }
        return false;
    }
        
        // This function will check if there is a tie. 
        bool Board::is_a_tie(){
            bool tie;
            for(int i=0; i<3; i++){
                if (tie != (gameboard[i][0] != gameboard[i][1]) && (gameboard[i][0] != gameboard[i][2])) {
                    tie = true;
                    std::cout << "It's a tie" << std::endl;
                }
            }
        return tie;
        }
        