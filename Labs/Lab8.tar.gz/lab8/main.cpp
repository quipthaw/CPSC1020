/*
   Manning Graham   
   mcgraha        
   Lab 8
   Lab Section: 4                  
*/ 
#include <vector>
#include <string>
#include <sstream>
#include <iostream>
#include "board.cpp"
using namespace std;
int main(){
string input;
numTurns = 0;
while(numTurns < 100);
    numTurns +=1;
    string print();
        if((numTurns%2)== 1){
            int pos = 0;
            cout << "Player x, Which position would you like to play?" << endl;
            cin >> input;
        }
    }
